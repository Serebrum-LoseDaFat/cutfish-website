Cutfish brand icons — concept A2, tight gap (record-play: play-button tail, round record-light body)

Colors: Ink #0E1A2B · Coral #FF5B3A · White #FFFFFF · Black #000000 (icon background)
Wordmark: Bricolage Grotesque Bold, converted to outlines (no font needed).

icons-black/  App icons, favicons and social avatar on a black background
icons-white/  The same set on a white background
  svg/      app icon (rounded + square), favicon.svg
  png/      app icons 1024/512/192, store-ready square 1024, 800px social avatar
  favicon/  favicon.ico (16/32/48), PNG favicons, apple-touch-icon (180), android-chrome 192/512
svg/          Mark (for light/dark backgrounds, mono ink/white) and horizontal logo (light/dark)
png/          Marks at 1000px and horizontal logos at 2000px

Web <head>:
  <link rel="icon" href="/favicon.ico" sizes="any">
  <link rel="icon" href="/favicon.svg" type="image/svg+xml">
  <link rel="apple-touch-icon" href="/apple-touch-icon.png">

Use the square app icon for App Store / Play Store (they apply their own corner mask).
Bricolage Grotesque is licensed under the SIL Open Font License.
